# Nosirt Map Deployment Notes

The live map now uses an optimized image asset:

```text
assets/maps/nosirt-map.webp
```

This file is full resolution at 5016 x 5016 pixels, but compressed for the web.
The original source PNG is not needed in the deployed site.

## What to upload to GitHub

Commit the whole updated site folder, including:

```text
assets/maps/nosirt-map.webp
assets/maps/nosirt-map-preview.webp
map-canvas.js
map-layout.js
styles.css
```

Do not commit the original 43 MB `Nosirt Map.png` unless you specifically want
GitHub to store the source artwork. Visitors only need the `.webp`.

## Replacing the map later

To swap in a new map without changing code:

1. Convert the new source image to WebP.
2. Name it exactly `nosirt-map.webp`.
3. Replace `assets/maps/nosirt-map.webp`.
4. If the dimensions change, update `MAP_W`, `MAP_H`, and `PIN_LOCS` in
   `map-canvas.js` / `map-layout.js`.

If the replacement stays 5016 x 5016, only the clickable coordinates may need
adjustment.

## Current clickable targets

The current pins are mapped to prominent features in the new artwork:

```text
garden   -> central lower meadow/garden area
square   -> bottom-left town
forum    -> purple tower
castle   -> large right-side castle
wireless -> harbor/coastal town
```

Weather, rain, snow, clouds, lightning, birds, dragons, and parallax overlays
still render above the image-backed map.
